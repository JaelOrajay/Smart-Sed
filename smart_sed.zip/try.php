
          <div class="row">
            <i class="fa-solid fa-house-laptop"></i>
            <input type="text" placeholder="HOUSE ID">
          </div>
          <div class="row">
            <i class="fas fa-lock"></i>
            <input type="password" placeholder="PASSWORD">
          </div>
           <div class="row button">
            <input type="submit" value="Login">
            <a href="index.php"><button type="submit" class="btn">Cancel</button></a>
    