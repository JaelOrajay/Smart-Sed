<!DOCTYPE html>
<!-- Coding By CodingNepal - youtube.com/codingnepal -->
<html lang="en" dir="ltr">
  <head>
  <?php
    $qrcode = $_GET['qrcode'];
    $url = 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data='.$qrcode;
    $img = './img/'.$qrcode.'.jpg';
    file_put_contents($img, file_get_contents($url));
    echo '<div style = "height: 400px;
    background: #fff;
    border-radius: 7px;
    padding: 20px 25px 0;
    transition: height 0.2s ease;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);">
      <header>
        <h1>QR Code Generator</h1>
        <br>
        <a href="./img/'.$qrcode.'.jpg" download="qrcode"><img type ="image"
         src = "https://api.qrserver.com/v1/create-qr-code/?size=300x300&data='.$qrcode.'" 
        alt="qrcode" 
         id = "qrcode"> </a>
      </header>
    </div>';
    ?>
    <meta charset="utf-8">
    <title>QR Code Generator </title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
	  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
	  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
	  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
	  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
	  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
	  <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.3.1/css/all.css'>
    <link rel="stylesheet" href="style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  </head>
  <body>
    <nav class="navbar navbar-expand-lg bg-light fixed-top">
			<div class="container">
				<div class="navbar-br"><i class="bi bi-house-fill"></i>SED</div>
				<button class="navbar-toggler" type="button" data-bs-toggle="collapse"
					data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
					aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="navbarSupportedContent">
					<ul class="navbar-nav ms-auto mb-2 mb-lg-0">
						<li class="nav-item">
							<a><i class="bi bi-qr-code"></i>&nbsp;GENERATE YOUR QR CODE &emsp;&emsp;&nbsp;</a>
						</li>
            <li class="nav-cancel">
							<a href="index.php" style="text-decoration:none">CANCEL</a>
						</li>
					</ul>
				</div>
			</div>
		</nav>

    

  </body>
</html>